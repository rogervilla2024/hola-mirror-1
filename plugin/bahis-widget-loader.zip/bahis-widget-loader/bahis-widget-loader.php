<?php
/**
 * Plugin Name: Bahis Widget Loader
 * Description: JSON verisini sunucuda cekip HTML olarak icerige gomer. Normal + AMP for WP uyumlu, mobil responsive, 6 slot ayarlanabilir.
 * Version: 3.17.0
 * Author: editor
 */

if (!defined('ABSPATH')) exit;

define('BWL_OPT', 'bwl_slots');
define('BWL_BASE_OPT', 'bwl_base_url');
define('BWL_NUM_SLOTS', 6);
define('BWL_DEFAULT_CENTRAL', 'https://hola-cot.pages.dev');

/**
 * 10 CF Pages mirror'i (hepsi ayni icerigi servis eder — mirror repolarindan otomatik sync).
 * Admin panelinde dropdown'da bunlardan biri secilir; boylece her WP sitesi farkli bir
 * CF hesabindan cekmis olur (yuk dagilimi + tek CF hesabi cakisirsa yedek).
 */
function bwl_mirrors() {
    return [
        'https://hola-cot.pages.dev',
        'https://hola-mirror-1.pages.dev',
        'https://nobody-hola2.pages.dev',
        'https://heybro-hola3.pages.dev',
        'https://helena4.pages.dev',
        'https://tati55.pages.dev',
        'https://santi666.pages.dev',
        'https://cehilo7.pages.dev',
        'https://blackmirror8.pages.dev',
        'https://trante9.pages.dev',
    ];
}

/**
 * Kaynak URL cozumu (ilk eslesen kazanir):
 *  1. wp-config.php'de BWL_BASE_URL sabiti tanimliysa onu kullan (deploy-time lock)
 *  2. Admin panelinde dropdown'dan secilen bwl_base_url option
 *  3. Merkez default: hola-cot.pages.dev -- konfigurasyonsuz calisir
 *
 * Not: file manager'a hicbir sey yazilmaz. Runtime'da wp_remote_get ile cekilir,
 *      6 saat transient'ta cache'lenir, hata durumunda LKG (last-known-good) devrede.
 */
function bwl_base_url() {
    if (defined('BWL_BASE_URL') && BWL_BASE_URL) return rtrim(BWL_BASE_URL, '/');
    $opt = rtrim((string) get_option(BWL_BASE_OPT, ''), '/');
    if ($opt !== '') return $opt;
    return rtrim(BWL_DEFAULT_CENTRAL, '/');
}

/**
 * Dropdown whitelist — sadece bwl_mirrors() icindekiler kabul edilir.
 * Bos deger -> default'a duser. Gecersiz URL -> bos'a cevrilir (yine default).
 */
function bwl_sanitize_base_url($v) {
    $v = trim((string) $v);
    if ($v === '') return '';
    $v = esc_url_raw($v);
    if (!preg_match('~^https?://~i', $v)) return '';
    $v = rtrim($v, '/');
    if (!in_array($v, bwl_mirrors(), true)) return '';
    return $v;
}

/* ---------- Self-update (markete koymadan) ----------
 * Update meta JSON, sitenin secili mirror'indan okunur ({mirror}/plugin/bahis-widget-loader.json).
 * Tum mirror'lar hola'dan sync oldugu icin JSON + ZIP hepsinde bulunur.
 * Yeni surum: hola/plugin/ altina zip + json guncelle -> push. Siteler otomatik guncellenir.
 */
define('BWL_UPDATE_JSON', '/plugin/bahis-widget-loader.json');
define('BWL_PLUGIN_SLUG', 'bahis-widget-loader');

if (file_exists(__DIR__ . '/plugin-update-checker/plugin-update-checker.php')) {
    require_once __DIR__ . '/plugin-update-checker/plugin-update-checker.php';
}

/** PUC instance'i (tek sefer olusur; test/debug icin erisilebilir). */
function bwl_update_checker() {
    static $puc = null;
    if ($puc === null && class_exists('\YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $puc = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            bwl_base_url() . BWL_UPDATE_JSON,
            __FILE__,
            BWL_PLUGIN_SLUG
        );
    }
    return $puc;
}
bwl_update_checker();

/* Bu eklenti icin otomatik guncelleme acik: 100 siteyi tek tek gezmeye gerek yok. */
add_filter('auto_update_plugin', function ($update, $item) {
    if (isset($item->slug) && $item->slug === BWL_PLUGIN_SLUG) return true;
    return $update;
}, 10, 2);

/* ---------- AMP tespit ---------- */

function bwl_is_amp() {
    if (function_exists('ampforwp_is_amp_endpoint') && ampforwp_is_amp_endpoint()) return true;
    if (function_exists('amp_is_request') && amp_is_request()) return true;
    if (function_exists('is_amp_endpoint') && is_amp_endpoint()) return true;
    return false;
}

/* ---------- Tum logolari onceden indir (prefetch) ----------
 * {mirror}/logos/index.json listesindeki her dosya uploads/bwl-logos/ altina indirilir.
 * Tetik: aktivasyon, eklenti guncellemesi, gunluk cron. Sadece eksik olanlar indirilir.
 */
function bwl_prefetch_logos() {
    $base = bwl_base_url();
    if ($base === '') return 0;
    $res = wp_remote_get($base . '/logos/index.json', ['timeout' => 10]);
    if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) return 0;
    $list = json_decode(wp_remote_retrieve_body($res), true);
    if (!is_array($list)) return 0;
    list($dir) = bwl_logo_dir();
    if ($dir === '') return 0;
    $n = 0;
    foreach ($list as $name) {
        $name = basename((string) $name);
        if (!preg_match('~^[A-Za-z0-9._-]+\.(png|jpe?g|gif|webp|svg)$~i', $name)) continue;
        $file = $dir . '/' . $name;
        if (file_exists($file) && filesize($file) > 0) continue;
        if (bwl_download_logo($name, $base . '/logos/' . $name)) $n++;
    }
    return $n;
}
add_action('bwl_prefetch_logos', 'bwl_prefetch_logos');

function bwl_schedule_prefetch() {
    if (!wp_next_scheduled('bwl_prefetch_logos')) {
        wp_schedule_single_event(time() + 10, 'bwl_prefetch_logos'); // hemen (arka planda)
    }
    if (!wp_next_scheduled('bwl_prefetch_logos_daily')) {
        wp_schedule_event(time() + DAY_IN_SECONDS, 'daily', 'bwl_prefetch_logos_daily');
    }
}
add_action('bwl_prefetch_logos_daily', 'bwl_prefetch_logos');

register_activation_hook(__FILE__, 'bwl_schedule_prefetch');
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('bwl_prefetch_logos');
    wp_clear_scheduled_hook('bwl_prefetch_logos_daily');
});
// Otomatik guncelleme sonrasi da calissin (activation hook update'te tetiklenmez)
add_action('upgrader_process_complete', function ($upgrader, $hook_extra) {
    if (($hook_extra['type'] ?? '') !== 'plugin') return;
    $me = plugin_basename(__FILE__);
    $plugins = $hook_extra['plugins'] ?? [];
    if (in_array($me, (array) $plugins, true) || ($hook_extra['plugin'] ?? '') === $me) bwl_schedule_prefetch();
}, 10, 2);
// Eski surumden gelen (activation hook calismamis) siteler icin: gunluk cron yoksa kur
add_action('init', function () {
    if (!wp_next_scheduled('bwl_prefetch_logos_daily')) bwl_schedule_prefetch();
});

/* ---------- Default ayarlar ---------- */

function bwl_default_slots() {
    return [
        ['enabled' => 1, 'type' => 'banner', 'position' => 'before',    'paragraph' => 0, 'data_file' => 'bahis-banner.json',  'title' => '',                          'max' => 0],
        ['enabled' => 1, 'type' => 'table',  'position' => 'after_p',   'paragraph' => 1, 'data_file' => 'bahis.json',         'title' => 'En Iyi Bahis Siteleri',      'max' => 8],
        ['enabled' => 0, 'type' => 'banner', 'position' => 'after_p',   'paragraph' => 4, 'data_file' => 'casino-banner.json', 'title' => '',                          'max' => 0],
        ['enabled' => 0, 'type' => 'table',  'position' => 'after_p',   'paragraph' => 6, 'data_file' => 'casino.json',        'title' => 'En Iyi Casino Siteleri',     'max' => 8],
        ['enabled' => 0, 'type' => 'banner', 'position' => 'after_p',   'paragraph' => 10, 'data_file' => 'bahis-banner.json',  'title' => '',                          'max' => 0],
        ['enabled' => 0, 'type' => 'table',  'position' => 'after',     'paragraph' => 0, 'data_file' => 'all.json',           'title' => 'Genel Siralama',             'max' => 10],
    ];
}

function bwl_get_slots() {
    $stored = get_option(BWL_OPT);
    if (!is_array($stored) || empty($stored)) return bwl_default_slots();
    return $stored;
}

/* ---------- JSON fetch + cache ---------- */

function bwl_get_data($path) {
    $base = bwl_base_url();
    if ($base === '') return [];
    $url = $base . '/data/' . $path;
    $cache_key = 'bwl_' . md5($url);
    $lkg_key   = 'bwlkg_' . md5($url);

    $cached = get_transient($cache_key);
    if ($cached !== false) return $cached;

    $res = wp_remote_get($url, ['timeout' => 5]);
    $data = null;
    if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
        $decoded = json_decode(wp_remote_retrieve_body($res), true);
        if (is_array($decoded)) $data = $decoded;
    }

    if ($data !== null) {
        set_transient($cache_key, $data, 6 * HOUR_IN_SECONDS); // 6 saat cache
        update_option($lkg_key, $data, false);
        return $data;
    }

    // Fetch basarisiz — LKG'den son iyi veriyi don, kisa retry cache'i koy
    $lkg = get_option($lkg_key);
    $fallback = is_array($lkg) ? $lkg : [];
    set_transient($cache_key, $fallback, 60);
    return $fallback;
}

function bwl_sanitize_data_file($v) {
    $v = sanitize_text_field((string) $v);
    return preg_match('/^[a-z0-9_-]+\.json$/i', $v) ? $v : 'bahis.json';
}

/**
 * Mevcut JSON dosyalari — dropdown icin optgroup halinde kategorize edildi.
 * Yeni bir kisayol domain'i eklendiginde bu listeye de eklenmeli.
 */
function bwl_data_files() {
    return [
        'Karma' => [
            'all.json' => 'Tum siteler',
        ],
        'Bahis - Tablo' => [
            'bahis.json'                => 'shortlinks.biz (default)',
            'bahiscustomizable.json'    => 'customizable.link',
            'bahiscustomshort.json'     => 'customshort.link',
            'bahiscustomurl.json'       => 'customurl.link',
            'bahisgenerateurl.json'     => 'generateurl.link',
            'bahismanageurl.json'       => 'manageurl.link',
            'bahisshortening.json'      => 'shortening.link',
            'bahisshortenurl.json'      => 'shortenurl.link',
            'bahisshortenurls.json'     => 'shortenurls.link',
            'bahissiteurl.json'         => 'siteurl.link',
            'bahisurlmanage.json'       => 'urlmanage.link',
            'bahisurlshortening.json'   => 'urlshortening.link',
            'bahisurlsites.json'        => 'urlsites.link',
            'bahisurlsshort.json'       => 'urlsshort.link',
        ],
        'Bahis - Banner' => [
            'bahis-banner.json'                => 'shortlinks.biz (default)',
            'bahis-banner-customizable.json'   => 'customizable.link',
            'bahis-banner-customshort.json'    => 'customshort.link',
            'bahis-banner-customurl.json'      => 'customurl.link',
            'bahis-banner-generateurl.json'    => 'generateurl.link',
            'bahis-banner-manageurl.json'      => 'manageurl.link',
            'bahis-banner-shortening.json'     => 'shortening.link',
            'bahis-banner-shortenurl.json'     => 'shortenurl.link',
            'bahis-banner-shortenurls.json'    => 'shortenurls.link',
            'bahis-banner-siteurl.json'        => 'siteurl.link',
            'bahis-banner-urlmanage.json'      => 'urlmanage.link',
            'bahis-banner-urlshortening.json'  => 'urlshortening.link',
            'bahis-banner-urlsites.json'       => 'urlsites.link',
            'bahis-banner-urlsshort.json'      => 'urlsshort.link',
        ],
        'Casino - Tablo' => [
            'casino.json'               => 'shortlinks.biz (default)',
            'casinocustomizable.json'   => 'customizable.link',
            'casinocustomshort.json'    => 'customshort.link',
            'casinocustomurl.json'      => 'customurl.link',
            'casinogenerateurl.json'    => 'generateurl.link',
            'casinomanageurl.json'      => 'manageurl.link',
            'casinoshortening.json'     => 'shortening.link',
            'casinoshortenurl.json'     => 'shortenurl.link',
            'casinoshortenurls.json'    => 'shortenurls.link',
            'casinositeurl.json'        => 'siteurl.link',
            'casinourlmanage.json'      => 'urlmanage.link',
            'casinourlshortening.json'  => 'urlshortening.link',
            'casinourlsites.json'       => 'urlsites.link',
            'casinourlsshort.json'      => 'urlsshort.link',
        ],
        'Casino - Banner' => [
            'casino-banner.json'                => 'shortlinks.biz (default)',
            'casino-banner-customizable.json'   => 'customizable.link',
            'casino-banner-customshort.json'    => 'customshort.link',
            'casino-banner-customurl.json'      => 'customurl.link',
            'casino-banner-generateurl.json'    => 'generateurl.link',
            'casino-banner-manageurl.json'      => 'manageurl.link',
            'casino-banner-shortening.json'     => 'shortening.link',
            'casino-banner-shortenurl.json'     => 'shortenurl.link',
            'casino-banner-shortenurls.json'    => 'shortenurls.link',
            'casino-banner-siteurl.json'        => 'siteurl.link',
            'casino-banner-urlmanage.json'      => 'urlmanage.link',
            'casino-banner-urlshortening.json'  => 'urlshortening.link',
            'casino-banner-urlsites.json'       => 'urlsites.link',
            'casino-banner-urlsshort.json'      => 'urlsshort.link',
        ],
    ];
}

/* ---------- Yardimcilar ---------- */

function bwl_logo_url($src) {
    $src = trim((string)$src);
    if ($src === '') return '';
    if (preg_match('~^(https?:|//|data:)~i', $src)) return $src;

    $basename = basename($src);

    // Local-first: WP Media Library'de ayni isimde bir dosya var mi? Varsa onu servis et.
    // Yoksa CF Pages URL'ine dus. Boylece kullanici herhangi bir logoyu manuel WP admin'den
    // yukleyip lokal servis edebilir; hicbir sey yuklemezse global JSON kaynagindan gelir.
    $local = bwl_local_logo_url($basename);
    if ($local !== '') return bwl_same_host_url($local);

    $base = bwl_base_url();
    if ($base === '') return '';
    $remote = $base . '/logos/' . $basename;

    // Auto-local: logoyu bir kez uploads/bwl-logos/ altina indir, sonra hep oradan servis et.
    // Boylece ziyaretcinin tarayicisi mirror'a hic gitmez; mirror acilmasa da resimler durur.
    $auto = bwl_auto_logo_url($basename, $remote);
    if ($auto !== '') return $auto;

    return $remote;
}

/**
 * Yerel URL'yi, sayfanin acildigi domain'e gore yeniden yaz.
 * Ornek: WP site adresi xxx.net ama sayfa https://xxx.top/amp/ uzerinden aciliyorsa
 * resimler de https://xxx.top/... olarak verilir (ayni docroot'u paylasan domainler icin).
 * wp-config'de BWL_KEEP_SITE_HOST true ise devre disi.
 */
function bwl_same_host_url($url) {
    if (defined('BWL_KEEP_SITE_HOST') && BWL_KEEP_SITE_HOST) return $url;
    $host = isset($_SERVER['HTTP_HOST']) ? strtolower(trim((string) $_SERVER['HTTP_HOST'])) : '';
    if ($host === '' || !preg_match('~^[a-z0-9.-]+(:\d+)?$~', $host)) return $url;
    $p = wp_parse_url($url);
    if (empty($p['host']) || empty($p['path'])) return $url;
    $scheme = is_ssl() ? 'https' : 'http';
    return $scheme . '://' . $host . $p['path'] . (isset($p['query']) ? '?' . $p['query'] : '');
}

/* ---------- Auto-local logo cache (uploads/bwl-logos/) ---------- */

define('BWL_LOGO_DIR', 'bwl-logos');
define('BWL_LOGO_TTL', DAY_IN_SECONDS);      // bu sureden eski dosya arka planda yenilenir
define('BWL_LOGO_RETRY', 10 * MINUTE_IN_SECONDS); // basarisiz indirme sonrasi bekleme

function bwl_logo_dir() {
    $up = wp_upload_dir();
    if (!empty($up['error'])) return ['', ''];
    return [untrailingslashit($up['basedir']) . '/' . BWL_LOGO_DIR, untrailingslashit($up['baseurl']) . '/' . BWL_LOGO_DIR];
}

/**
 * Yerel kopya varsa URL'ini don (eskiyse yenilemeyi cron'a birak).
 * Yoksa indir; indirme basarisizsa '' don (cagiran uzak URL'e duser).
 */
function bwl_auto_logo_url($basename, $remote) {
    if (!preg_match('~^[A-Za-z0-9._-]+\.(png|jpe?g|gif|webp|svg)$~i', $basename)) return '';
    list($dir, $url) = bwl_logo_dir();
    if ($dir === '') return '';
    $file = $dir . '/' . $basename;

    if (file_exists($file) && filesize($file) > 0) {
        if (time() - (int) filemtime($file) > BWL_LOGO_TTL && !wp_next_scheduled('bwl_refresh_logo', [$basename, $remote])) {
            wp_schedule_single_event(time() + 30, 'bwl_refresh_logo', [$basename, $remote]);
        }
        return bwl_same_host_url($url . '/' . $basename . '?v=' . (int) filemtime($file));
    }

    // Kisa sure once denenip basarisiz olduysa tekrar deneme (her sayfa yukunde HTTP atma)
    if (get_transient('bwl_logofail_' . md5($basename))) return '';

    return bwl_download_logo($basename, $remote) ? bwl_same_host_url($url . '/' . $basename . '?v=' . (int) filemtime($file)) : '';
}

function bwl_download_logo($basename, $remote) {
    list($dir) = bwl_logo_dir();
    if ($dir === '') return false;
    if (!wp_mkdir_p($dir)) return false;
    if (!file_exists($dir . '/index.html')) @file_put_contents($dir . '/index.html', '');

    $res = wp_remote_get($remote, ['timeout' => 5]);
    if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) {
        set_transient('bwl_logofail_' . md5($basename), 1, BWL_LOGO_RETRY);
        return false;
    }
    $body = wp_remote_retrieve_body($res);
    $ctype = (string) wp_remote_retrieve_header($res, 'content-type');
    if ($body === '' || strlen($body) > 2 * MB_IN_BYTES || (stripos($ctype, 'image/') !== 0 && stripos($ctype, 'svg') === false)) {
        set_transient('bwl_logofail_' . md5($basename), 1, BWL_LOGO_RETRY);
        return false;
    }
    // Atomik yaz: eski dosya, yeni dosya tam yazilana kadar yerinde kalir
    $tmp = $dir . '/.' . $basename . '.tmp';
    if (@file_put_contents($tmp, $body) === false) return false;
    if (!@rename($tmp, $dir . '/' . $basename)) { @unlink($tmp); return false; }
    return true;
}

add_action('bwl_refresh_logo', function ($basename, $remote) {
    list($dir) = bwl_logo_dir();
    $file = $dir . '/' . $basename;
    // Indirme basarisizsa eski dosyaya dokunma; TTL'i uzat ki her 30 sn'de tekrar denemesin
    if (!bwl_download_logo($basename, $remote) && file_exists($file)) @touch($file);
}, 10, 2);

/**
 * WP Media Library'de basename ile eslesen upload varsa URL'ini dondur.
 * Yoksa bos string. Hem pozitif hem negatif sonuc 6 saat transient'a cache'lenir
 * (media table'i her sayfa render'inda sorgulanmasin). add_attachment /
 * edit_attachment / delete_attachment hook'lari cache'i kanser eder.
 *
 * Ornek: JSON'da image "../logos/celtabet.png" -> basename "celtabet.png" -> DB'de
 * _wp_attached_file LIKE '%celtabet.png' -> "2026/08/celtabet.png" -> URL dondurulur.
 */
function bwl_local_logo_url($basename) {
    $basename = trim((string) $basename);
    if ($basename === '') return '';

    $cache_key = 'bwl_localimg_' . md5($basename);
    $cached = get_transient($cache_key);
    if ($cached !== false) return (string) $cached; // '' = negative cache

    global $wpdb;
    $like = '%' . $wpdb->esc_like($basename);
    $sql = $wpdb->prepare(
        "SELECT post_id FROM {$wpdb->postmeta}
         WHERE meta_key = %s AND meta_value LIKE %s
         LIMIT 1",
        '_wp_attached_file',
        $like
    );
    $attachment_id = (int) $wpdb->get_var($sql);

    $url = '';
    if ($attachment_id > 0) {
        $u = wp_get_attachment_url($attachment_id);
        if (is_string($u) && $u !== '') $url = $u;
    }

    set_transient($cache_key, $url, 6 * HOUR_IN_SECONDS);
    return $url;
}

/**
 * Media Library'de yeni upload/silme/rename olunca local logo cache'ini komple kanser et.
 * Boylece kullanici celtabet.png yukleyince bir sonraki page load'ta lokali gorur.
 */
function bwl_flush_logo_cache() {
    global $wpdb;
    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE '_transient_bwl_localimg_%'
            OR option_name LIKE '_transient_timeout_bwl_localimg_%'"
    );
}
add_action('add_attachment',    'bwl_flush_logo_cache');
add_action('edit_attachment',   'bwl_flush_logo_cache');
add_action('delete_attachment', 'bwl_flush_logo_cache');

function bwl_stars($rating) {
    $r = max(0, min(5, floatval($rating)));
    $full = (int) floor($r);
    $half = ($r - $full) >= 0.5 ? 1 : 0;
    $empty = 5 - $full - $half;
    return str_repeat('*', $full) . ($half ? '.' : '') . str_repeat('-', $empty);
}

/* ---------- Responsive stil bloku (enqueue ile head'e / amp-custom'a basilir) ---------- */

function bwl_styles_css() {
    // Minified, media-query'li stil. Enqueue edildigi icin AMP'te amp-custom'a girer (!important korunur).
    // Element bazindaki inline stiller kritik-render fallback icin ayrica kaliyor.
    return
         // === RESET LAYER 1 === all:revert tarayici default'una donduryor (tema stil'ini iptal eder)
         // Sadece .bwl-wrap ve altindaki elementler etkilenir, sayfanin geri kalani dokunulmaz.
           '.bwl-wrap,.bwl-wrap *{all:revert;box-sizing:border-box}'
         . '.bwl-wrap *{max-width:none;max-height:none}'

         // === RESET LAYER 2 === tema `!important` icin agresif override. tr/td/th/table
         // uzerindeki padding, margin, border, text-indent — hepsi tema tarafindan setlenebilir.
         // Bunlari (0,2,2)+ specificity + !important ile yikiyoruz.
         . '.bwl-wrap{padding:0!important;margin:18px auto!important;text-indent:0!important;text-align:center!important}'
         . '.bwl-wrap table.bwl-tbl{'
         .   'padding:0!important;margin:0 auto!important;'
         .   'border:0!important;border-collapse:collapse!important;border-spacing:0!important;'
         .   'text-indent:0!important;width:100%!important;'
         . '}'
         . '.bwl-wrap table.bwl-tbl caption{padding:0 0 10px 0!important;margin:0!important;text-indent:0!important}'
         . '.bwl-wrap table.bwl-tbl tr,'
         . '.bwl-wrap table.bwl-tbl thead,'
         . '.bwl-wrap table.bwl-tbl tbody{'
         .   'height:auto!important;line-height:normal!important;'
         .   'padding:0!important;margin:0!important;border:0!important;text-indent:0!important;'
         . '}'
         . '.bwl-wrap table.bwl-tbl td,'
         . '.bwl-wrap table.bwl-tbl th{'
         .   'height:auto!important;line-height:normal!important;'
         .   'margin:0!important;text-indent:0!important;'
         . '}'

         // === BASE STYLES ===
         . '.bwl-wrap{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;margin:18px auto;color:#1a1a1a;display:block;text-align:center}'
         . '.bwl-caption{caption-side:top;text-align:center;font-size:17px;font-weight:600;padding:0 0 10px 0;color:#1a1a1a}'
         . '.bwl-title{font-size:17px;font-weight:600;margin:0 0 10px 0}'
         . '.bwl-tbl{display:table!important;width:100%!important;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;box-shadow:none}'
         // Default td/th padding — !important + yuksek specificity ile tema kurallarini yener
         . '.bwl-wrap table.bwl-tbl th,'
         . '.bwl-wrap table.bwl-tbl td{'
         .   'padding:8px 5px!important;text-align:center!important;vertical-align:middle!important;border-bottom:1px solid #eee;'
         . '}'
         . '.bwl-tbl th{font-size:12px;font-weight:600;text-transform:uppercase;color:#555;background:#f7f7f9;letter-spacing:.04em}'
         . '.bwl-tbl tr:last-child td{border-bottom:0}'
         // #-numara kolonu: first-child oldugu icin tema'nin `td:first-child` padding'ini
         // (ornegin 20px) O emer — logo ikinci kolona kayar ve tema kuralindan etkilenmez.
         . '.bwl-c-rank{width:22px;text-align:center}'
         . '.bwl-rank{font-weight:700;color:#111;font-size:13px}'
         // 102px = 100px logo + 2x1px padding (border-box'ta da content-box'ta da logoyu sikmaz)
         . '.bwl-c-logo{width:102px;text-align:center}'
         . '.bwl-c-bonus{text-align:center}'
         . '.bwl-c-cta{width:auto;text-align:center;white-space:nowrap}'
         . '.bwl-c-rate{width:48px;text-align:center}'
         // NUCLEAR specificity — class-repeat trick (.bwl-wrap x3) ile (0,5,2)+ specificity.
         // Hem shorthand `padding` hem longhand (top/right/bottom/left) hem logical (inline-start/end)
         // ayri ayri !important — tema hangi sekilde yazmis olursa olsun (padding, padding-left,
         // padding-inline-start) hepsi yakalanir.
         // Not: `td:first-child` artik #-rank kolonu; onu SIKMIYORUZ — tema padding'ini
         // bilerek emsin. Sadece logo + cta hucrelerini class ile sikilastiriyoruz.
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl td.bwl-c-logo,'
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl td.bwl-c-cta,'
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl th.bwl-c-logo,'
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl th.bwl-c-cta{'
         .   'padding:1px!important;'
         .   'padding-top:1px!important;'
         .   'padding-right:1px!important;'
         .   'padding-bottom:1px!important;'
         .   'padding-left:1px!important;'
         .   'padding-inline-start:1px!important;'
         .   'padding-inline-end:1px!important;'
         .   'padding-block-start:1px!important;'
         .   'padding-block-end:1px!important;'
         . '}'
         // line-height:0 SADECE td'lerde — th'lerde basliklarin ("Site"/"Link") satiri collapse olur.
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl td.bwl-c-logo,'
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl td.bwl-c-cta{line-height:0!important}'
         // bonus + puan hucreleri: yatay padding cimri — 360px'te "20.000 TL" tek satirda kalsin
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl td.bwl-c-bonus,'
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl td.bwl-c-rate,'
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl th.bwl-c-bonus,'
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl th.bwl-c-rate{'
         .   'padding-left:3px!important;padding-right:3px!important;'
         . '}'
         // #-rank hucresi: sol padding'i tema td:first-child ile ezilebilir (AMP'te 20px'e cikar),
         // ama sag padding bizde kalir — numarayi sola cekip logodan ayirir. Non-AMP'te bu yuksek
         // specificity kural sol padding'i de 4px'e sabitler.
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl td.bwl-c-rank,'
         . '.bwl-wrap.bwl-wrap.bwl-wrap table.bwl-tbl th.bwl-c-rank{'
         .   'padding-top:8px!important;padding-bottom:8px!important;'
         .   'padding-left:4px!important;padding-right:5px!important;'
         . '}'
         // vertical-align:middle — AMP <img>'i inline'a cevirdiginde baseline descender bosluğu
         // logoyu satirda ~4px yukari itiyordu. display:block gecerse bu deger yoksayilir,
         // gecmezse (AMP/tema) inline kutuyu hucre ortasina oturtur. Ikisi birlikte guvenli.
         // Logo linki flex — line box / baseline olusmadigi icin resmin altinda olu alan kalmaz
         . '.bwl-logo-link{display:flex!important;align-items:center;justify-content:center;line-height:0;text-decoration:none!important;border:0;box-shadow:none!important}'
         . '.bwl-logo-link:hover{text-decoration:none!important}'
         . '.bwl-logo{display:block;width:100px!important;min-width:100px!important;height:40px!important;object-fit:contain;margin:0 auto;vertical-align:middle!important}'
         . '.bwl-cta{display:inline-block;padding:9px 12px;background:#16a34a;color:#fff!important;text-decoration:none;border-radius:6px;font-weight:600;font-size:13px;white-space:nowrap;line-height:1;box-sizing:border-box;box-shadow:none!important;text-shadow:none!important;filter:none!important}'
         . '.bwl-cta:hover{background:#15803d;box-shadow:none!important}'
         . '.bwl-bonus-p{font-size:16px;font-weight:700;color:#16a34a;line-height:1.2}'
         . '.bwl-bonus-n{display:inline-block;margin-left:5px;font-size:10px;font-weight:700;color:#fff;background:#f59e0b;padding:2px 5px;border-radius:4px;letter-spacing:.04em;vertical-align:middle}'
         . '.bwl-bonus-a{font-size:11px;color:#555;margin-top:2px}'
         . '.bwl-rate{font-weight:700;color:#f59e0b;font-size:13px;white-space:nowrap}'
         . '.bwl-star{color:#f59e0b}'
         . '.bwl-banner{display:block;text-align:center;margin:14px auto;line-height:0}'
         // vertical-align:middle — banner inline-block oldugu icin baseline descender bosluğu
         // resmin altina ~4px olu alan birakiyor (tema line-height:0'i ezerse). Bu onu kapatir.
         . '.bwl-banner img{display:inline-block;max-width:100%;height:auto;border:0;vertical-align:middle}'
         // Tablet & buyuk mobil: 4 sutun korunur, sadece padding/font sikilastirilir (logo 100x40 sabit)
         . '@media (max-width:640px){'
         .   '.bwl-tbl th,.bwl-tbl td{padding:8px 4px!important}'
         .   '.bwl-title,.bwl-caption{font-size:16px}'
         .   '.bwl-c-rate{width:44px!important}'
         .   '.bwl-cta{padding:8px 10px!important;font-size:12px!important}'
         .   '.bwl-bonus-p{font-size:15px!important}'
         . '}'
         // Kucuk mobil (360px): 4 sutun hala korunur — logo 100x40, buton "Git" kompakt,
         // padding minimum, puan mini. Kart layout'a GECILMEZ (AMP ile tutarli tek duzen).
         . '@media (max-width:480px){'
         .   '.bwl-tbl th,.bwl-tbl td{padding:8px 3px!important}'
         .   '.bwl-c-logo{width:102px!important}' // 100px logo + 2x1px padding — daha az olamaz
         .   '.bwl-c-rate{width:40px!important}'
         .   '.bwl-cta{padding:8px 8px!important;font-size:12px!important}'
         .   '.bwl-bonus-p{font-size:14px!important}'
         .   '.bwl-bonus-a{font-size:10px!important;color:#555}'
         .   '.bwl-bonus-n{font-size:9px!important;padding:1px 4px!important;margin-left:3px!important}'
         .   '.bwl-rate{font-size:11px!important}'
         . '}';
}

/**
 * CSS'i enqueue ile head'e bas. Src'siz handle => sadece inline CSS basilir, ekstra
 * HTTP istegi yok.
 *
 * AMP notu: bu stylesheet AMP sayfasinda GARANTI DEGIL — tree-shake / 75KB amp-custom
 * butcesi onu tamamen atabiliyor (scr3'te DevTools "Computed > padding" listesinde
 * .bwl-* kurallarindan hicbiri gorunmuyordu, sadece tema kurallari + inline'dan uretilen
 * .acss* class'lari vardi). Bu yuzden hucre olculeri (padding/width/logo boyutu) inline
 * style ile de yaziliyor ve ORASI tek guvenilir kanal. Inline'da kural:
 *   - !important YASAK (AMP declaration'i komple siler),
 *   - ayni property'yi iki kez yazma (AMP ilkini tutar, sonrakini atar).
 */
function bwl_enqueue_styles() {
    // AMP'te is_singular sık false doner (ampforwp ozel loop) — AMP kontrolu
    // OR ile eklenmis, boylece AMP sayfalarinda da CSS enqueue edilir.
    // Non-AMP'te ayrica homepage/front-page dahil edildi ki v3.10.0'daki widget
    // ana sayfa fix'iyle CSS'in de basmasi saglansin.
    if (!bwl_is_amp() && !is_singular() && !is_home() && !is_front_page()) return;
    wp_register_style('bwl-inline', false, [], '3.11.0');
    wp_enqueue_style('bwl-inline');
    wp_add_inline_style('bwl-inline', bwl_styles_css());
}
add_action('wp_enqueue_scripts', 'bwl_enqueue_styles');

/* ---------- JSON-LD schema (Product + AggregateRating icin rich snippet) ---------- */

function bwl_render_jsonld($items, $title) {
    if (empty($items) || !is_array($items)) return '';
    $list = [];
    foreach ($items as $i => $it) {
        if (!is_array($it)) continue;
        $rating = floatval($it['rating'] ?? 0);
        $product = [
            '@type' => 'Product',
            'name'  => (string)($it['title'] ?? ''),
            'image' => (string) bwl_logo_url($it['image'] ?? ''),
            'url'   => (string)($it['url'] ?? ''),
        ];
        if ($rating > 0) {
            $product['aggregateRating'] = [
                '@type'       => 'AggregateRating',
                'ratingValue' => $rating,
                'bestRating'  => 5,
                'worstRating' => 1,
                'ratingCount' => 1,
            ];
        }
        $list[] = [
            '@type'    => 'ListItem',
            'position' => $i + 1,
            'item'     => $product,
        ];
    }
    if (empty($list)) return '';
    $schema = [
        '@context'        => 'https://schema.org',
        '@type'           => 'ItemList',
        'name'            => (string)$title,
        'itemListElement' => $list,
    ];
    return '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

/* ---------- Tablo render (SEO tables + isolated CSS) ---------- */

function bwl_render_table($data_file, $title = '', $max = 0) {
    $items = bwl_get_data($data_file);
    if (empty($items)) return '';
    if ($max > 0) $items = array_slice($items, 0, $max);

    // Inline fallback (AMP + CSS bloklandiginda calisir)
    //
    // AMP KURALI — inline style'da IKI SEY YASAK:
    //   1) !important — AMP author CSS'te yasak; sanitizer o declaration'i KOMPLE ATAR.
    //   2) Ayni property'yi iki kez yazmak — style="" -> .acss* class'ina cevrilirken
    //      ILK yazilan kaliyor, sonraki eziliyor (normal CSS'in tersi).
    // Bu yuzden base string'te padding YOK; her hucre padding'ini TEK SEFER kendisi yazar.
    // (Eskiden `padding:8px 5px` + `padding:1px !important` yaziyorduk; AMP 5px'i tutuyor,
    //  logo hucresinde 10px padding kaliyor ve 100px'lik logo 93px'e iniyordu.)
    $th   = 'text-align:center;font-size:11px;font-weight:600;text-transform:uppercase;color:#555;background:#f7f7f9;border-bottom:1px solid #eee;letter-spacing:.03em';
    $td   = 'text-align:center;font-size:13px;vertical-align:middle;border-bottom:1px solid #eee';
    // Hucre bazli padding'ler — 360px'te toplam ~300px'lik alani boyle paylasiyoruz:
    // # 17px + logo 102px (100 logo + 2 padding) + Git ~50px + Puan ~43px -> bonus'a ~88px kalir.
    $pad_rank  = 'padding:8px 5px 8px 4px'; // sag padding logoyu numaradan ayirir
    $pad_tight = 'padding:1px';             // logo + Git: hucreyi icerige sikica sarar
    $pad_text  = 'padding:8px 3px';         // bonus + puan: yatayda cimri, metne yer acar

    $html  = '<div class="bwl-wrap" style="font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;margin:18px auto;color:#1a1a1a;text-align:center">';
    // JSON-LD structured data (rich snippet icin)
    $html .= bwl_render_jsonld($items, $title);
    // display:table SART — bircok tema/AMP eklentisi mobilde `table{display:block;overflow-x:auto}`
    // uyguluyor (tasma korkusuyla). O kural aktifken tablo bloğu %100 genisler ama ic yapisi
    // anonim tabloya donup ICERIGE gore buzulur: scr4'te tablo 300px'te kalip container'in
    // sagında ~40px beyaz bosluk birakiyordu. Inline `display:table` o kurali yener (AMP'te
    // stylesheet'lerin !important'i silindigi icin inline en guclu kanal).
    $html .= '<table class="bwl-tbl" style="display:table;width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;box-shadow:none">';
    if ($title !== '') {
        // <caption> — SEO-canonical table baslik, screen reader'lar dogru okur
        $html .= '<caption class="bwl-caption" style="caption-side:top;text-align:center;font-size:17px;font-weight:600;margin-bottom:10px;padding:0 0 10px 0;color:#1a1a1a">' . esc_html($title) . '</caption>';
    }
    $html .= '<thead><tr>'
        // Not: th'lerde line-height:0 YOK — basliklar ("Site"/"Link") metin, cizgi yuksekligi gerekir.
           . '<th class="bwl-c-rank" scope="col" style="' . $th . ';width:22px;' . $pad_rank . '">#</th>'
           . '<th class="bwl-c-logo" scope="col" style="' . $th . ';width:102px;' . $pad_text . '">Site</th>'
           . '<th class="bwl-c-bonus" scope="col" style="' . $th . ';' . $pad_text . '">Bonus</th>'
           . '<th class="bwl-c-cta" scope="col" style="' . $th . ';' . $pad_text . '">Link</th>'
           . '<th class="bwl-c-rate" scope="col" style="' . $th . ';width:48px;' . $pad_text . '">Puan</th>'
           . '</tr></thead><tbody>';

    foreach ($items as $idx => $it) {
        $rank   = (int) $idx + 1;
        $img    = esc_url(bwl_logo_url($it['image'] ?? ''));
        $url    = esc_url($it['url'] ?? '#');
        $name   = esc_html($it['title'] ?? '');
        $bonus  = $it['bonus'] ?? [];
        $rating = floatval($it['rating'] ?? 0);

        $bonus_html = '';
        if (!empty($bonus['percent']) || !empty($bonus['amount'])) {
            // Amount = birincil bilgi (buyuk, yesil) — dikkat cekici
            if (!empty($bonus['amount'])) {
                // Not: bonus['note'] ("Nakit" vb.) rozeti kaldirildi — sade gorunum.
                $bonus_html .= '<div class="bwl-bonus-p" style="font-size:17px;font-weight:700;color:#16a34a;line-height:1.2">' . esc_html($bonus['amount']) . '</div>';
            }
            // Percent = ikincil bilgi (kucuk, gri). Etiket: JSON'da note "nakit" iceriyorsa
            // "Nakit", yoksa "Bonus" — ikisi de bas harfi buyuk.
            if (!empty($bonus['percent'])) {
                $label = (!empty($bonus['note']) && stripos($bonus['note'], 'nakit') !== false) ? 'Nakit' : 'Bonus';
                $bonus_html .= '<div class="bwl-bonus-a" style="font-size:12px;color:#555;margin-top:2px">' . esc_html($bonus['percent']) . ' ' . $label . '</div>';
            }
        }

        $html .= '<tr>';
        // #-rank hucresi first-child — tema'nin td:first-child padding'ini emer, logo korunur.
        $html .= '<td class="bwl-c-rank" style="' . $td . ';width:22px;' . $pad_rank . '"><span class="bwl-rank" style="font-weight:700;color:#111;font-size:13px">' . $rank . '</span></td>';
        // width/height HTML attribute'lari AMP icin kritik — amp-img bunlari birebir kullanir.
        // Aspect 3:1 (240x80) — bahis/casino logolarinin cogu wide format, bu oran onlar icin uygun.
        // Non-AMP'te CSS max-width/max-height + object-fit:contain devraliyor.
        // width:102px = 100px logo + 2x1px padding. min-width:100px logoyu kilitler:
        // AMP'in amp-wp-enforced-sizes kurali (max-width:100%) hucre daralirsa logoyu kucultur,
        // min-width CSS'te max-width'i yener — logo her kosulda 100x40 kalir.
        // Logo da Git ile ayni linke gidiyor — tiklama alani buyur, alt metni korunur.
        //
        // Link kutusu display:flex — DIKEY HIZA SORUNUNUN KOKUNU KESER: flex container'da
        // satir kutusu (line box) ve taban cizgisi yoktur, yani temanin line-height'inden gelen
        // ~7px inis payi hic olusmaz. Logo bu olu alan yuzunden satirda 3.5px yukarida duruyordu
        // (scr5 olcumu: ustte 7.5px, altta 14.5px). Kutu artik tam 40px; hucrenin
        // vertical-align:middle'i tam ortaliyor — magic-number padding telafisine gerek yok.
        $html .= '<td class="bwl-c-logo" style="' . $td . ';width:102px;' . $pad_tight . ';line-height:0"><a class="bwl-logo-link" href="' . $url . '" target="_blank" rel="nofollow sponsored noopener" style="display:flex;align-items:center;justify-content:center;line-height:0;text-decoration:none;border:0"><img class="bwl-logo" src="' . $img . '" alt="' . $name . '" width="100" height="40" style="display:block;width:100px;min-width:100px;height:40px;object-fit:contain;margin:0 auto;vertical-align:middle"></a></td>';
        $html .= '<td class="bwl-c-bonus" style="' . $td . ';' . $pad_text . '">' . $bonus_html . '</td>';
        $html .= '<td class="bwl-c-cta" style="' . $td . ';' . $pad_tight . ';line-height:0"><a class="bwl-cta" href="' . $url . '" target="_blank" rel="nofollow sponsored noopener" style="display:inline-block;padding:9px 12px;background:#16a34a;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;font-size:13px;white-space:nowrap;line-height:1;box-shadow:none;text-shadow:none;filter:none">Git</a></td>';
        $html .= '<td class="bwl-c-rate" style="' . $td . ';width:48px;' . $pad_text . '"><div class="bwl-rate" style="font-weight:700;color:#f59e0b;font-size:13px;white-space:nowrap">' . number_format($rating, 1) . ' <span class="bwl-star" style="color:#f59e0b">&#9733;</span></div></td>';
        $html .= '</tr>';
    }
    $html .= '</tbody></table></div>';
    return $html;
}

/* ---------- Banner render ---------- */

function bwl_render_banner($data_file) {
    $d = bwl_get_data($data_file);
    if (!is_array($d) || empty($d['url']) || empty($d['image'])) return '';

    $url = esc_url($d['url']);
    $img = esc_url(bwl_logo_url($d['image']));
    $alt = esc_attr($d['alt'] ?? '');
    $w   = intval($d['width'] ?? 320);
    $h   = intval($d['height'] ?? 50);

    return '<div class="bwl-banner" style="text-align:center;margin:14px auto;line-height:0"><a href="' . $url . '" target="_blank" rel="nofollow sponsored noopener"><img src="' . $img . '" alt="' . $alt . '" width="' . $w . '" height="' . $h . '" style="max-width:100%;height:auto;border:0;vertical-align:middle"></a></div>';
}

/* ---------- Slot render ---------- */

function bwl_render_slot($slot) {
    if (empty($slot['enabled'])) return '';
    if (!isset($slot['type']) || !isset($slot['data_file'])) return '';
    if ($slot['type'] === 'banner') return bwl_render_banner($slot['data_file']);
    if ($slot['type'] === 'table')  return bwl_render_table($slot['data_file'], $slot['title'] ?? '', intval($slot['max'] ?? 0));
    return '';
}

/* ---------- Enjeksiyon yardimcisi ---------- */

function bwl_inject_after_paragraph($content, $snippet, $paragraph_num) {
    if ($snippet === '' || !is_string($content)) return $content;
    $count = 0;
    $inserted = false;
    $result = preg_replace_callback('~</p>~i', function ($m) use ($snippet, $paragraph_num, &$count, &$inserted) {
        $count++;
        if ($count === $paragraph_num) {
            $inserted = true;
            return '</p>' . $snippet;
        }
        return '</p>';
    }, $content);
    if (!$inserted) $result .= $snippet;
    return $result;
}

/* ---------- Icerige reklamlari uygula ---------- */

function bwl_inject_widgets($content) {
    if (!is_string($content) || $content === '') return $content;
    $slots = bwl_get_slots();
    if (empty($slots)) return $content;

    $before = '';
    $after  = '';
    $any    = false;
    foreach ($slots as $slot) {
        if (empty($slot['enabled'])) continue;
        $html = bwl_render_slot($slot);
        if ($html === '') continue;
        $any = true;
        $pos = $slot['position'] ?? 'after_p';
        if ($pos === 'before')      $before .= $html;
        elseif ($pos === 'after')   $after .= $html;
        else                        $content = bwl_inject_after_paragraph($content, $html, intval($slot['paragraph'] ?? 1));
    }
    // CSS artik enqueue ile head'e/amp-custom'a basiliyor (bwl_enqueue_styles).
    // Boylece AMP eklentileri stil'i <style amp-custom>'a tasir ve !important korunur.
    return $before . $content . $after;
}

/* ---------- Hook: tek filter, cift render onleyici ---------- */

add_filter('the_content', function ($content) {
    // Bir istekte sadece BIR kere inject et (ana sayfa gibi loop'lu sayfalarda
    // her post excerpt'i tetiklerdi — buradaki flag bir kereye kilitler)
    static $injected_this_request = false;
    if ($injected_this_request) return $content;

    // Ozet (excerpt) uretimi de the_content filtresini tetikler (wp_trim_excerpt):
    // enjekte edilen reklam HTML'i hemen ardindan strip_tags ile silinir, ustelik
    // yukaridaki kilit bosa tuketilir — AMP anasayfada 5 yazilik listede reklamin
    // hic gorunmemesinin nedeni buydu. Excerpt baglamindaysak kilide dokunmadan cik.
    if (function_exists('doing_filter') && doing_filter('get_the_excerpt')) return $content;

    $is_amp = bwl_is_amp();

    if ($is_amp) {
        // AMP'te is_singular / in_the_loop / is_main_query cogu zaman false doner
        // (AMP for WP ozel bir loop kuruyor, ana query'nin dışında). Bu kontrolleri
        // atla — AMP renderer zaten tek bir post icin the_content uretiyor.
        // scr: tebaren.org/amp/ sayfasinda widget HTML yoktu, cunku is_main_query()
        // false donuyordu; guard eklenmeden bwl_inject_widgets direkt cagriliyor artik.
    } else {
        // Tek yazi/sayfa VE ana sayfa VE front page — hepsinde calis.
        if (!is_singular() && !is_home() && !is_front_page()) return $content;

        // Ana query'nin loop'unda olmak sart — sidebar/widget'lardaki the_content'te calisma.
        // Sadece non-AMP'te uygulanir; AMP'te yukarida atlandi.
        if (function_exists('in_the_loop') && function_exists('is_main_query')) {
            if (!in_the_loop() || !is_main_query()) return $content;
        }
    }

    $injected_this_request = true;
    return bwl_inject_widgets($content);
}, 20);

/* ---------- AMP liste sayfalari (anasayfa/arsiv): header altina ust reklam ----------
 * AMP for WP anasayfa ve arsivler yazilari OZET olarak listeler; the_content
 * enjeksiyonu orada asla gorunmez (excerpt tum HTML'i strip eder). Bu yuzden
 * 'before' (yazinin basinda) konumlu slotlar bu sayfalarda ampforwp_after_header
 * kancasiyla header'in hemen altina direkt basilir.
 * Tekil AMP yazilara dokunulmaz — orada the_content enjeksiyonu zaten calisiyor. */

function bwl_amp_imgify($html) {
    // Kanca ciktisi AMP for WP'nin content sanitizer'indan GECMEZ; duz <img> AMP'te
    // gecersiz olur ve sayfa valid olmaz. amp-img'e cevir. layout="intrinsic" =
    // width/height oranini koruyup max-width:100% gibi kuculen davranis (img esdegeri).
    return preg_replace('~<img\b([^>]*?)\s*/?>~i', '<amp-img layout="intrinsic"$1></amp-img>', $html);
}

add_action('ampforwp_after_header', function () {
    static $done = false;
    if ($done || !bwl_is_amp()) return;

    // Sadece liste sayfalarinda calis (anasayfa / custom front page / arsiv).
    // POZITIF tespit sart: "singular degilse bas" deseydik, AMP'te is_singular'in
    // yanlis false donmesi tekil yazida cift reklama yol acardi.
    $is_list = false;
    if (function_exists('ampforwp_is_front_page') && ampforwp_is_front_page()) $is_list = true;
    elseif (function_exists('ampforwp_is_home') && ampforwp_is_home()) $is_list = true;
    elseif (!is_singular() && (is_home() || is_front_page() || is_archive())) $is_list = true;
    if (!$is_list) return;

    $html = '';
    foreach (bwl_get_slots() as $slot) {
        if (empty($slot['enabled'])) continue;
        if (($slot['position'] ?? '') !== 'before') continue;
        $html .= bwl_render_slot($slot);
    }
    if ($html === '') return;
    $done = true;
    echo bwl_amp_imgify($html);
});

/* ---------- Ayarlar sayfasi ---------- */

add_action('admin_menu', function () {
    add_options_page('Bahis Widget Loader', 'Bahis Widget Loader', 'manage_options', 'bwl-settings', 'bwl_settings_page');
});

add_action('admin_init', function () {
    register_setting('bwl_group', BWL_OPT, ['sanitize_callback' => 'bwl_sanitize_slots']);
    register_setting('bwl_group', BWL_BASE_OPT, ['sanitize_callback' => 'bwl_sanitize_base_url']);
});

function bwl_sanitize_slots($input) {
    if (!is_array($input)) return bwl_default_slots();
    $out = [];
    foreach ($input as $s) {
        $out[] = [
            'enabled'   => !empty($s['enabled']) ? 1 : 0,
            'type'      => in_array($s['type'] ?? '', ['banner', 'table'], true) ? $s['type'] : 'table',
            'position'  => in_array($s['position'] ?? '', ['before', 'after', 'after_p'], true) ? $s['position'] : 'after_p',
            'paragraph' => max(0, intval($s['paragraph'] ?? 1)),
            'data_file' => bwl_sanitize_data_file($s['data_file'] ?? 'bahis.json'),
            'title'     => sanitize_text_field($s['title'] ?? ''),
            'max'       => max(0, intval($s['max'] ?? 0)),
        ];
    }
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_bwl_%' OR option_name LIKE '_transient_timeout_bwl_%'");
    return $out;
}

function bwl_settings_page() {
    $slots = bwl_get_slots();
    $positions = [
        'before'  => 'Yazinin basinda',
        'after_p' => 'N. paragraftan sonra',
        'after'   => 'Yazinin sonunda',
    ];
    $types = [
        'table'  => 'Tablo',
        'banner' => 'Banner',
    ];
    ?>
    <div class="wrap">
        <h1>Bahis Widget Loader</h1>
        <p>Reklam slotlarini buradan yonet. Kaydettiginde cache otomatik temizlenir.</p>
        <form method="post" action="options.php">
            <?php settings_fields('bwl_group'); ?>

            <?php
            $const_base   = defined('BWL_BASE_URL') && BWL_BASE_URL ? rtrim(BWL_BASE_URL, '/') : '';
            $opt_base     = (string) get_option(BWL_BASE_OPT, '');
            $default_base = rtrim(BWL_DEFAULT_CENTRAL, '/');
            $active       = bwl_base_url();
            if ($const_base !== '') {
                $source = 'wp-config.php (BWL_BASE_URL constant)';
            } elseif ($opt_base !== '') {
                $source = 'Admin override (asagidaki alan)';
            } else {
                $source = 'Default merkez CDN (' . $default_base . ')';
            }
            ?>
            <h2 style="margin-top:20px">Kaynak URL</h2>
            <p><strong>Su an aktif:</strong> <code><?php echo esc_html($active); ?></code> &nbsp;<em>(<?php echo esc_html($source); ?>)</em></p>

            <?php if ($const_base !== ''): ?>
                <p class="description">wp-config.php'de <code>BWL_BASE_URL</code> tanimli, admin ayari yok sayilir. Degistirmek icin constant'i kaldir.</p>
                <input type="text" value="<?php echo esc_attr($const_base); ?>" style="width:100%;max-width:520px" disabled>
            <?php else: ?>
                <select name="<?php echo esc_attr(BWL_BASE_OPT); ?>" style="width:100%;max-width:520px">
                    <option value=""><?php echo esc_html('— Default (' . $default_base . ') —'); ?></option>
                    <?php foreach (bwl_mirrors() as $mirror): ?>
                        <option value="<?php echo esc_attr($mirror); ?>" <?php selected($opt_base, $mirror); ?>>
                            <?php echo esc_html($mirror); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <p class="description">
                    <strong>10 CF Pages mirror'i</strong> — hepsi ayni icerigi servis eder (otomatik sync). Bu siteye ozel bir tanesi sec, boylece her WP sitesi farkli CF hesabindan ceker (yuk dagilimi).
                    <strong>Bos secim</strong> = default (<code><?php echo esc_html($default_base); ?></code>).
                    <br><em>Not: JSON runtime'da sunucudan cekilir (6 saat cache), file manager'a hicbir sey yazilmaz. wp-config.php'de <code>define('BWL_BASE_URL', '...')</code> ile de sabitlenebilir.</em>
                </p>
            <?php endif; ?>

            <h2 style="margin-top:24px">Slot Ayarlari</h2>
            <table class="widefat striped" style="margin-top:10px">
                <thead>
                    <tr>
                        <th style="width:60px">Aktif</th>
                        <th style="width:100px">Tip</th>
                        <th style="width:180px">Konum</th>
                        <th style="width:80px">Paragraf</th>
                        <th>Veri dosyasi</th>
                        <th>Baslik</th>
                        <th style="width:80px">Max</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($slots as $i => $s):
                    $s = wp_parse_args($s, ['enabled'=>0,'type'=>'table','position'=>'after_p','paragraph'=>1,'data_file'=>'','title'=>'','max'=>0]);
                ?>
                    <tr>
                        <td><input type="checkbox" name="<?php echo BWL_OPT; ?>[<?php echo $i; ?>][enabled]" value="1" <?php checked($s['enabled'], 1); ?>></td>
                        <td>
                            <select name="<?php echo BWL_OPT; ?>[<?php echo $i; ?>][type]">
                                <?php foreach ($types as $k=>$v): ?>
                                <option value="<?php echo $k; ?>" <?php selected($s['type'], $k); ?>><?php echo esc_html($v); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="<?php echo BWL_OPT; ?>[<?php echo $i; ?>][position]">
                                <?php foreach ($positions as $k=>$v): ?>
                                <option value="<?php echo $k; ?>" <?php selected($s['position'], $k); ?>><?php echo esc_html($v); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td><input type="number" min="0" name="<?php echo BWL_OPT; ?>[<?php echo $i; ?>][paragraph]" value="<?php echo intval($s['paragraph']); ?>" style="width:60px"></td>
                        <td>
                            <select name="<?php echo BWL_OPT; ?>[<?php echo $i; ?>][data_file]" style="width:100%">
                                <?php
                                // Flat liste — optgroup yok. Her slot'ta tum 57 dosya kullanilabilir.
                                // Kullanici istedigi kombinasyonu yapabilir (bahis slot'unda casino,
                                // casino slot'unda bahis, banner slot'unda tablo, vs.)
                                foreach (bwl_data_files() as $group_label => $files):
                                    foreach ($files as $filename => $description): ?>
                                        <option value="<?php echo esc_attr($filename); ?>" <?php selected($s['data_file'], $filename); ?>>
                                            <?php echo esc_html($filename . ' — ' . $description); ?>
                                        </option>
                                    <?php endforeach;
                                endforeach; ?>
                            </select>
                        </td>
                        <td><input type="text" name="<?php echo BWL_OPT; ?>[<?php echo $i; ?>][title]" value="<?php echo esc_attr($s['title']); ?>" style="width:100%"></td>
                        <td><input type="number" min="0" name="<?php echo BWL_OPT; ?>[<?php echo $i; ?>][max]" value="<?php echo intval($s['max']); ?>" style="width:60px"></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p style="margin-top:20px;color:#666;font-size:13px">
                <strong>Konum notlari:</strong> "Yazinin basinda" ve "Yazinin sonunda" secilirse paragraf degeri kullanilmaz.<br>
                <strong>Veri dosyasi:</strong> <code>bahis.json</code>, <code>casino.json</code>, <code>bahis-banner.json</code> gibi.
            </p>
            <?php submit_button('Ayarlari Kaydet'); ?>
        </form>
    </div>
    <?php
}
